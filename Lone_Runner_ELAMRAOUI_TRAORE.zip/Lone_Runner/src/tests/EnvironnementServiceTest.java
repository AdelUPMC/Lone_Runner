package tests;
import static org.junit.Assert.*;

import org.junit.Test;
public class EnvironnementServiceTest {

	public EnvironnementServiceTest() {
		// TODO Auto-generated constructor stub
	}

}
