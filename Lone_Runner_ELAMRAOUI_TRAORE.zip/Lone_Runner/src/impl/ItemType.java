package impl;

public enum ItemType {
	Treasure;
}	
