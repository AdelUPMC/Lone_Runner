package Exceptions;

public class InvariantError extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvariantError() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvariantError(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InvariantError(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvariantError(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvariantError(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

	
}
