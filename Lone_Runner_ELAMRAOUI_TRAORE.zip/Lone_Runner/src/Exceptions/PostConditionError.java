package Exceptions;

public class PostConditionError extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PostConditionError() {
		// TODO Auto-generated constructor stub
	}

	public PostConditionError(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PostConditionError(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public PostConditionError(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PostConditionError(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
