package services;

public enum CellNature {
	EMP,
	PLT,
	HOL,
	LAD,
	HDR,
	MTL
}
